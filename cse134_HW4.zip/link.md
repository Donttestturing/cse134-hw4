
URL: [My Website](https://fantastic-nougat-5d563f.netlify.app/)



URL: [Native Dialogs](https://fantastic-nougat-5d563f.netlify.app/nativedialogs.html)

URL: [Custom Dialogs](https://fantastic-nougat-5d563f.netlify.app/customdialogs.html)

URL: [Basic CRUD](https://fantastic-nougat-5d563f.netlify.app/crud.html)

URL: [Styled CRUD](https://fantastic-nougat-5d563f.netlify.app/styledcrud.html)

URL: [Github Repo](https://github.com/Donttestturing/cse134-hw4)
